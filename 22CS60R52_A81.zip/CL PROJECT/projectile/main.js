const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const start = document.getElementById('start');
const reset = document.getElementById('reset');
const vInput = document.getElementById('velocity');
const aInput = document.getElementById('angle');
const radiusInput = document.getElementById('ballRadius');
const radiusLabel = document.getElementById('radiusLabel');
const rangeInput = document.getElementById('canvasRange');
const rangeLabel = document.getElementById('rangeLabel');

// canvas.width = 

class Ball {
	constructor(velocity, angle, x, y, r) {
		this.vInit = velocity;
		this.angInit = angle;
		this.setVelocity(velocity, angle);
		this.xInit = 0;
		this.x = x;
		this.yInit = 0;
		this.y = y;
		this.radius = r;
		this.maxHeight = 0;
	}
	
	setVelocity(velocity, angle) {
		let radAngle = angle * Math.PI / 180;
		this.vx = velocity * Math.cos(radAngle);
		this.vy = velocity * Math.sin(radAngle);
	}
	
	setRadius(val) {
		this.radius = val;
		clearCanvas();
		this.draw();
	}
	
	updatePosition() {
		let time = timer.elapsedTime();
		this.x = this.xInit + this.vx * time;
		this.y = this.yInit + this.vy * time + 0.5 * gravity * time * time;
		if (this.y < 0) {
			this.y = 0;
			animator.stop();
			const reqBody = {
				u: this.vInit,
				theta: this.angInit,
				time: time,
				maxHeight: this.maxHeight,
				range: this.x
			}
			fetch("/projectile", {
				method: "POST",
				body: JSON.stringify(reqBody)
			}).then(response => response.text())
			.then(data => console.log(data));
			// console.log(this.vInit, this.angInit, time, this.maxHeight);
		}
	}
	
	draw() {
		ctx.fillStyle = 'rgb(220, 0, 0)';
		ctx.beginPath();
		ctx.arc((this.x + this.radius) * pixelsPerMeter, canvas.height - (this.y + this.radius) * pixelsPerMeter, this.radius * pixelsPerMeter, 0, 2 * Math.PI);
		ctx.fill();
		this.drawText();
	}
	
	drawText() {
		ctx.fillStyle = 'black';
		ctx.font = '20px monospace';
		let elapsedTime, distance, height;
		if (animator.isRunning() || (this.x == this.xInit && this.y == this.yInit)) {
			[elapsedTime, distance, height] = this.getStandardText();
		} else {
			[elapsedTime, distance, height] = this.getFinalText();
		}
		ctx.fillText('t: ' + elapsedTime.toFixed(2) + ' s', 10, 30);
		ctx.fillText('x: ' + distance.toFixed(2) + ' m', 10, 50);
		ctx.fillText('y: ' + height.toFixed(2) + ' m', 10, 70);
		// ctx.fillText('y: ' + height.toFixed(2) + ' m', 10, 70);
		ctx.fillText('y-max: ' + this.maxHeight.toFixed(2) + ' m', 10, 90);
	}
	
	getStandardText() {
		let elapsedTime = timer.elapsedTime();
		this.maxHeight = Math.max(this.maxHeight, this.y);
		// console.log(yMax, this.y);
		return [elapsedTime, this.x, this.y];
	}
	
	getFinalText() {
		let vf = -Math.sqrt(this.vy * this.vy + 2 * -gravity * this.yInit);
		let elapsedTime = (vf - this.vy) / gravity;
		let height = this.yInit + this.vy * elapsedTime + 0.5 * gravity * elapsedTime * elapsedTime;
		let distance = this.xInit + this.vx * elapsedTime;
		this.maxHeight = Math.max(this.maxHeight, height);
		return [elapsedTime, distance, height];
	}
}

class Timer {
	constructor() {
		this.time = undefined;
		this.startTime = undefined;
	}
	
	setTime(time) {
		if (this.time === undefined) {
			this.startTime = time;
		}
		this.time = time;
	}
	
	elapsedTime() {
		let elapsedTime = Math.floor(this.time - this.startTime) / 1000 || 0;
		return elapsedTime;
	}
}

class Animator {
	constructor() {
		this.running = false;
	}
	
	start() {
		this.running = true;
		requestAnimationFrame(render);
	}
	
	stop() {
		this.running = false;
	}
	
	isRunning() {
		return this.running;
	}
}

clearCanvas = () => {
	ctx.fillStyle = 'rgb(150, 150, 255)';
	ctx.fillRect(0, 0, canvas.width, canvas.height);
}

initializeScene = () => {
	pixelsPerMeter = canvas.width / +rangeInput.value;
	gravity = -9.8;
	clearCanvas();
	animator.stop();
	ball = new Ball(+vInput.value, +aInput.value, 0, 0, +radiusInput.value/100);
	timer = new Timer();
	ball.draw();
}

render = time => {
	if (!animator.isRunning()) {
		return;
	}
	timer.setTime(time);
	clearCanvas();
	ball.updatePosition();
	ball.draw();
	requestAnimationFrame(render);
}


//Main
let ball;
let timer;
let animator = new Animator();
let pixelsPerMeter;
let gravity;
initializeScene();

start.onclick = () => {
	initializeScene();
	animator.start();
}
reset.onclick = () => initializeScene();

const inputs = document.getElementsByClassName('text_entry');
for (let input of inputs) {
	input.oninput = () => initializeScene();
	input.onfocus = () => input.select();
}
radiusInput.oninput = () => {
	ball.setRadius(+radiusInput.value/100);
	radiusLabel.innerHTML = 'Ball Radius: ' + radiusInput.value + 'cm';
}
rangeInput.oninput = () => {
	pixelsPerMeter = canvas.width / +rangeInput.value;
	rangeLabel.innerHTML = 'Canvas Range: ' + rangeInput.value + 'm';
	if( !animator.isRunning()) {
		clearCanvas();
		ball.draw();
	}
}