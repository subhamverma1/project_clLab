"""
 Implements a simple HTTP/1.0 Server

"""

import socket
import os
import sys
import json

results = {
    'projectile': [],
    'pendulum': [],
    'mirror': []
}

ROOT_DIR = ""
def get_page(file_name):
    path = ".{}/{}".format(ROOT_DIR, file_name)
    try:
        f = open(path, encoding="utf-8")
        content = f.read()
        return content
    except(FileNotFoundError):
       path = ".{}".format(file_name)
       f = open(path, encoding="utf-8")
       content = f.read()
       return content
    except:
        return ""

def get_resource(file_name):
    path = ".{}/{}".format(ROOT_DIR, file_name)
    try:
        f = open(path, mode="rb")
        content = f.read()
        return content
    except(FileNotFoundError):
       path = ".{}".format(file_name)
       f = open(path, mode="rb")
       content = f.read()
       return content
    except:
        return ""

# Define socket host and port
# SERVER_HOST = '0.0.0.0'
SERVER_HOST = sys.argv[1]
SERVER_PORT = int(sys.argv[2])

# Create socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((SERVER_HOST, SERVER_PORT))
server_socket.listen(5)
print('Listening on port %s ...' % SERVER_PORT)

while True:    
    # Wait for client connections
    client_socket, cli_addr = server_socket.accept()
    client_socket.settimeout(1.5)
    request = ""
    while True:
        try:
            chunk = client_socket.recv(4096)
            request += chunk.decode()
            if(not chunk):
                break
        except:
            break
    
    response = 'HTTP/1.0 200 OK\n\n'
    # print("Request:", request)
    if not request:
        continue
    headers = request.split("\r\n")
    # print("Headers:", headers)
    method = headers[0].split()[0]
    path = headers[0].split()[1]
    print("Request:", method, path)
    if (method == "GET"):
        if (path.endswith(".css") or path.endswith(".js") or path.endswith(".map") or path.endswith(".html")):
            response += get_page(path)
        elif (path.endswith(".pdf") or path.endswith(".png")):
            client_socket.send('HTTP/1.1 200 OK\r\n'.encode())
            if (path.endswith(".png")):
                client_socket.send("Content-Type: image/png\r\n".encode())
            elif(path.endswith(".pdf")):
                client_socket.send("Content-Type: application/pdf\r\n".encode())
            client_socket.send("Accept-Ranges: bytes\r\n\r\n".encode())
            response = get_resource(path)
            client_socket.send(response)
            continue
            print(response)
        elif (path == '/'):
            ROOT_DIR = "/"
            response += get_page("index.html")
        elif (path == '/projectile/results'):
            content = json.dumps(results['projectile']);
            response += content
        elif (path == '/projectile'):
            ROOT_DIR = path
            response += get_page("index.html")
        elif (path == '/mirror'):
            ROOT_DIR = path
            response += get_page("/index.html")
        elif (path == '/pendulum'):
            ROOT_DIR = path
            response += get_page("/index.html")
            # print(response)
        # elif (file == '')
        # if (file == '/pendulum'):
    elif(method == "POST"):
        body = json.loads(headers[len(headers) - 1])
        print('Request body', body)
        if(path == '/projectile'):
            results['projectile'].append(body)
            response += "{'msg': 'success'}"
    elif(method == "DELETE"):
        # body = json.loads(headers[len(headers) - 1])
        # print('Request body', body)
        if(path == '/projectile'):
            results['projectile'].clear()
            response += "{'msg': 'success'}"
            # response = "{'msg': 'Record updated'}"
    # response = 'HTTP/1.0 200 OK\n\nHello World'
    client_socket.sendall(response.encode())
    client_socket.close()

# Close socket
server_socket.close()