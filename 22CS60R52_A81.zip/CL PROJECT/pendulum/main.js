
let damping = 0;

function toggleDamping() {
	damping = !damping;
}

function Pendulum(origin_, r_, m_) {
	// Fill all variables
	this.path = [];
	this.origin = origin_.copy();
	this.position = createVector();
	this.r = r_;
	this.angle = PI / 4;

	this.aVelocity = 0.0;
	this.aAcceleration = 0.0;
	this.damping = 0.995 - 0.0005 * m;   // damping
	this.ballr = m_;      // time ball radio

	this.dragging = false;


	this.go = function () {
		// main sequence of the simulation
		this.update();  //calculate and update
		this.drag();    //user events
		this.display(); // draw
	};

	// Function to update position
	this.update = function () {
		this.damping = 0.995 - 0.0003 * m / 3;   // damping
		// As long as the pendulum is not held with the mouse, it continues to rotate
		if (!this.dragging) {
			var gravity = 0.1 * g;                                           //gravity
			this.aAcceleration = (-1 * gravity / this.r) * sin(this.angle);  // Calculate acceleration
			this.aVelocity += this.aAcceleration;                            // speed increase
			if(damping) {
				this.aVelocity *= this.damping;                                  // damping
			}
			this.angle += this.aVelocity;                                    //increase angle
			this.angle1 = this.angle * (180 / PI);
			// this.angle2=this.angle*(180/PI);


		}
	};

	this.display = function () {
		this.position.set(l * sin(this.angle), l * cos(this.angle), 0); // conversion cartesian -> polar
		this.position.add(this.origin);                                       //ref origin pendulum

		stroke('#e0ad16');
		strokeWeight(2);
		// draw arm
		line(this.origin.x, this.origin.y, this.position.x, this.position.y);

		ellipseMode(CENTER); //configure p5 to generate circles from the center

		this.path.push(new Point(this.position.x, this.position.y));
		if (this.path.length > 100) { this.path.splice(0, 1); }
		var c = 0;
		for (i in this.path) {
			fill(color(25, 25 + c++, 205));
			stroke(color(25, 25 + c++, 205));
			ellipse(this.path[i].x, this.path[i].y, 5, 5);
		}

		stroke('#e0ad16');
		fill('#9b9888');
		if (this.dragging) fill('#c66a0d');
		// draw ball
		circle(this.position.x, this.position.y, m, m);

	};


	// mouse drag interaction
	// if you are taking the pendulum

	this.clicked = function (mx, my) {
		var d = dist(mx, my, this.position.x, this.position.y);
		if (d < this.ballr) {
			this.dragging = true;
		}

	};

	// if you are no longer taking the pendulum
	this.stopDragging = function () {
		if (this.dragging) {
			this.aVelocity = 0; // speed is 0 when released
			this.dragging = false;
		}

	};

	this.drag = function () {
		// while holding the pendulum
		// calculate angle between
		// origin y mouse
		if (this.dragging) {
			var diff = p5.Vector.sub(this.origin, createVector(mouseX, mouseY));      // difference between points
			this.angle = atan2(-1 * diff.y, diff.x) - radians(90);                   // relative angle (vertical)
			this.angle1 = this.angle * (180 / PI);
			//this.angle2=this.angle*(180/PI);

		}
	};
}


function Point(x, y) {
	this.x = x;
	this.y = y;
}

var p;           //pendulum instance
var g = 9.82;    //average gravity on earth
var m = 50.0;    //masa
var l = 400.0;   //arm length



function setup() {

	createCanvas(720, 480).parent("#myCanvas");
	var v = createVector(width / 2, 0); //center stop position
	// Make a new Pendulum with an origin position and armlength
	p = new Pendulum(v, l, m);

}
goingup = false;
function draw() {

	background('#1c2438');
	p.go();
	stroke(51);
	fill(255);
	text('fps: ' + getFrameRate().toFixed(2), width - 80, 20);
	text('g  : ' + g.toFixed(2), width - 80, 35);
	text('L  : ' + l.toFixed(2), width - 80, 50);
	text('m  : ' + m.toFixed(2), width - 80, 65);
	text('You can Drag and Drop the pendulum', width - 600, 570);

	text('Angular Vel : ' + p.aVelocity.toFixed(2), width - 127, 105);
	text('Damping     : ' + p.damping.toFixed(3), width - 127, 120);
	text('Angle     : ' + p.angle.toFixed(3), width - 127, 135);
	text('Angle in degree : ' + p.angle1.toFixed(3), width - 127, 150);
	//text('Angle2     : ' + p.angle2.toFixed(3), width -120, 170);


}

function mousePressed() {
	p.clicked(mouseX, mouseY);
}

function mouseReleased() {
	p.stopDragging();
}
